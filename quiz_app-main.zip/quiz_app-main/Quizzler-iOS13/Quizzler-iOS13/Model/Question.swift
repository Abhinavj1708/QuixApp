//
//  questions.swift
//  Quizzler-iOS13
//
//  Created by V UMESH KUMAR RAJU on 06/05/21.
//  Copyright © 2021 The App Brewery. All rights reserved.
//

import Foundation

struct Question {
    let q : String
    let a : String
    init(q:String,a:String)
    {
        self.q=q
        self.a=a
    }
}
